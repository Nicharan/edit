package com.example.caps.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.caps.model.Coupon;





public interface CouponRepo extends JpaRepository<Coupon, Integer>{

}
